<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdraw</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>
<body class="bg-gray-100">
    <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4">Jumlah WD</h1>
        <p class="bg-gray-200 rounded-lg py-2 px-4 mb-4">Jangan gunakan titik (.) pada nominal</p>

        <form action="<?php echo e(route('simpan.transaksiwd')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input id="jumlahWD" name="jumlahWD" type="number" class="border border-gray-300 rounded-lg p-2 mb-4">

            <!-- Password -->
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => 'password','value' => __('Password')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'password','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Password'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['id' => 'password','class' => 'border border-gray-300 rounded-lg p-2 mb-4','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'current-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'password','class' => 'border border-gray-300 rounded-lg p-2 mb-4','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'current-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

            <!-- Tampilkan pesan error -->
            <?php if($errors->any()): ?>
                <div class="bg-red-100 text-red-500 rounded-lg py-2 px-4 mb-4">
                    <?php echo e($errors->first()); ?>

                </div>
            <?php endif; ?>

            <!-- Tampilkan pesan sukses -->
            <?php if(session('success')): ?>
                <div class="bg-green-100 text-green-500 rounded-lg py-2 px-4 mb-4">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <h2 class="text-xl font-bold mb-2">Nama rekening</h2>
            <p id="NamaRekUser"><?php echo e(auth()->user()->name); ?></p>

            <h2 class="text-xl font-bold mb-2">No. Rekening</h2>
            <div class="flex items-center mb-4 space-x-4">
                <button id="bank" class="bg-blue-500 text-white rounded-lg py-2 px-4"><?php echo e(auth()->user()->bank); ?></button>
                <p id="RekUser" class="mr-2"><?php echo e(auth()->user()->noRek); ?></p>
            </div>

            <div class="flex flex-col sm:flex-row">
                <button type="submit" name="action" value="kirim" class="bg-blue-500 text-white rounded-lg py-2 px-4 mb-2 sm:mb-0 sm:mr-2">Kirim</button>
                <button type="submit" name="action" value="batal" class="bg-blue-500 text-white rounded-lg py-2 px-4">
                    <a href="<?php echo e(route('dashboard')); ?>">Batal</a>
                </button>
            </div>
        </form>
    </div>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/BreezeLaravel/resources/views/withdraw.blade.php ENDPATH**/ ?>