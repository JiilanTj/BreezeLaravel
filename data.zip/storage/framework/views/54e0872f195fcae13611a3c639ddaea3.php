<head>
    <title>Macau4D</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
    </style>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script>
        function validateInputLength(inputId, jumlahId) {
            var input = document.getElementById(inputId);
            var jumlah = document.getElementById(jumlahId);

            if (input.value.length !== 4) {
                jumlah.disabled = true;
            } else {
                jumlah.disabled = false;
            }
        }
    </script>
</head>
<body>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="flex flex-col gap-y-4 items-center justify-center p-8" style="background-color: #fc8c2c">
    
<div class="flex flex-col bg-purple-700 gap-2 border-2 border-white rounded-xl border p-4">
    <div class="flex gap-2 flex-row">
        <div style="width: 25%">
            <button class="mx-2 px-4 py-1 text-white rounded-lg hover:bg-blue-600 h-14 w-full" style="background-color: #fc8c2c">
                <a href="/macau4d">4D</a>
            </button>
        </div>
        <div style="width: 25%">
            <button class="mx-2 px-4 py-1 text-white rounded-lg hover:bg-blue-600 h-14 w-full" style="background-color: #fc8c2c">
                <a href="/login">4D Campuran</a>
            </button>
        </div>
        <div style="width: 25%">
            <button class="mx-2 px-4 py-1 text-white rounded-lg hover:bg-blue-600 h-14 w-full" style="background-color: #fc8c2c">
                <a href="/login">3D</a>
            </button>
        </div>
        <div style="width: 25%">
            <button class="mx-2 px-4 py-1 text-white rounded-lg hover:bg-blue-600 h-14 w-full" style="background-color: #fc8c2c">
                <a href="/login">2D Depan</a>
            </button>
        </div>
    </div>
    <div class="flex gap-2 flex-row">
        <div style="width: 25%">
            <button class="mx-2 px-4 py-1 text-white rounded-lg hover:bg-blue-600 h-14 w-full" style="background-color: #fc8c2c">
                <a href="/login">2D Belakang</a>
            </button>
        </div>
        <div style="width: 25%">
            <button class="mx-2 px-4 py-1 text-white rounded-lg hover:bg-blue-600 h-14 w-full" style="background-color: #fc8c2c">
                <a href="/login">2D Tengah</a>
            </button>
        </div>
        <div style="width: 25%">
            <button class="mx-2 px-4 py-1 text-white rounded-lg hover:bg-blue-600 h-14 w-full" style="background-color: #fc8c2c">
                <a href="/login">Pola tarung</a>
            </button>
        </div>
        <div style="width: 25%">
            <button class="mx-2 px-4 py-1 text-white rounded-lg hover:bg-blue-600 h-14 w-full" style="background-color: #fc8c2c">
                <a href="/login">BB Campuran</a>
            </button>
        </div>
    </div>
</div>
        
        
    
            

    

    <div class="bg-purple-700 border-2 border-white rounded-xl border border-white p-4">
        <h1 class="text-center my-4 text-2xl text-white">4D Macau</h1>
        <h1 class="text-center my-4 text-lg  text-white">Pastikan Mengisi Angka Yang mau diisi Dahulu</h1>

        <?php if(session('success')): ?>
            <div class="text-green-500"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="text-red-500"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <form action="/macau4d/submit" method="POST">
            <?php echo csrf_field(); ?>

            <?php for($i = 1; $i <= 10; $i++): ?>
                <div class="flex flex-row justify-center mb-4">
                    <div class="flex">
                    <input type="number" id="angka<?php echo e($i); ?>" name="angka<?php echo e($i); ?>" class="border border-gray-300 px-2 py-1 rounded mx-2" oninput="validateInputLength('angka<?php echo e($i); ?>', 'jumlah<?php echo e($i); ?>')">
                    </div>
                    <div class="align-right">
                    <p class="text-2xl" style="ml-2 text-align: center; color: white;">      x </p>
                    </div>
                    <div class="flex justify-center items-center">
                    <input type="number" id="jumlah<?php echo e($i); ?>" name="jumlah<?php echo e($i); ?>" class="w-1/2 border border-gray-300 px-2 py-1 rounded mx-2" disabled>
                    </div>
                </div>
            <?php endfor; ?>

            <div class="flex justify-center">
                <button type="submit" class="text-white px-4 py-2 rounded" style="background-color: #fc8c2c">Submit</button>
            </div>
        </form>
    </div>
</div>
</body>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/BreezeLaravel/resources/views/macau4d.blade.php ENDPATH**/ ?>